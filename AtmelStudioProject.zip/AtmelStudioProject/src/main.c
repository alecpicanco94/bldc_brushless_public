/*
 * main.c
 *
 * Created: 07/11/2024 11:42:41
 *  Author: Alec Pican�o de Azevedo Lopes
 */ 

#include <avr/io.h>
#include <avr/interrupt.h> 

#include "../inc/hall_sensor.h"
#include "../inc/main.h"
#include "../inc/main_open_loop.h"
#include "../inc/main_close_loop.h"

int main(void) {
	
	/* PERIF�RICOS NECESS�RIOS PARA MALHA ABERTA/PARTIDA */
	Timer2_config();																					// CONFIGURA O TIMER 2 (GERAR O PWM)																								// PERIFERICOS NECESSARIOS PARA MALHA ABERTA
	Timer3_config();																					// CONFIGURA O TIMER 3 (MEDIR A VELOCIDADE DO ROTOR)
	Timer5_config();																					// INICIALIZA O TIMER 5 (GERAR DELAY'S DE CPU)
	GPIO_INIT();																						// DEFINE OS SENTIDOS DAS GPIO'S
	Align_Motor(20, 0.5);																				// FUNCAO PARA LINHAMENTO DO ROTOR
	Start_Motor();																						// PARTIDA EM MALHA ABERTA DO MOTOR BLDC
	
	/* PERIF�RICOS NECESS�RIOS PARA MALHA FECHADA */
	ADC_init();																							// INICIALIZA O ADC
	TIMSK2 |= 1 << TOIE2;																				// HABILITA A INTERRUP. POR OVERFLOW (LER POTENCIOMETRO)
	while (1) {																							// LOOP DE MALHA FECHADA
		if(SampleADC == true) {
			Get_ADC_Value();
			SampleADC = false;
		}
	}
}

void Align_Motor(int16_t delayms_align, double dutycycle_align) {

	AL_PORT &= ~AL_PIN;
	BH_PORT &= ~BH_PIN;
	CH_PORT &= ~CH_PIN;
	
	CL_PORT |= CL_PIN;		
	BL_PORT |= BL_PIN;
	AH_PORT |= AH_PIN;
	
	TCCR2B |= 1 << CS20 | 1 << CS21;																	// PRESCALER = 8 (GERARA PWM)
	setPWMValue(dutycycle_align);
	sei();
	delayTimer5_ms(delayms_align);
}

void Start_Motor(void) {
	double pwm = 0.5;
	step_Sector = 4;																					// SETOR AP�S O ALINHAMENTO DEFINIDO
	TCCR3B = (1 << CS30);																				// PRESCALER DE 1 (MEDIR VELOCIDADE)
	setPWMValue(pwm);																					// DEFINE O PWM COMO SENDO 50%
	delay = 6700;																					    // TEMPO DE COMUTA��O ENTRE OS SETORES
	while(!ZCP_DETECTED){
		PreDriver_Sequence = Sector_DIR_Sequence[step_Sector];											// INICIA O MOTOR NO SETOR 2 ou 4
		Sector_Update(PreDriver_Sequence);																// REALIZADA A TROCA DO SETOR	
		step_Sector = (step_Sector + 1) % 6;
		delayTimer5_us(delay);
		if( delay >= 2900 ){
			delay = delay - (6700 - 2900)/13;
			pwm = pwm + 0.01;
			setPWMValue(pwm);
		}
		//else{
			//PCINT0_init();																			// CONFIGURA INTERRUP��O DOS PINOS DE ZCP'S
		//}
	}
}

void Stop_Motor(void) {
  cli();																								// DESATIVA INTERRUP��ES GLOBAIS
  TCCR2B &= ~(1 << CS20 | 1 << CS21);
}

void Sector_Update (unsigned char Next_Hall_Sequence)
{
	switch(Next_Hall_Sequence)
	{
		case HS_C|LS_B:																					// SECTOR 6
		AL_PORT &= ~AL_PIN;
		AH_PORT &= ~AH_PIN;
		BH_PORT &= ~BH_PIN;
		CL_PORT &= ~CL_PIN;
		
		CH_PORT |= CH_PIN;
		BL_PORT |= BL_PIN;
		
		EICRA = ( 1 << ISC01 ) |( 1 << ISC00 );
		EIMSK = 1 << SENSORS_A_INT;																	    // HABILITA INTERRUP��O PARA ZCP A
		SENSORS_PIN_CHG = 0X05;																			// PINOS DO SENSOR DEVEM ESTAR COM VALOR 100
		if(ZCP_DETECTED) 	calculateRPM();
		break;
		
		case HS_B|LS_A:																					// SECTOR 4
		AH_PORT &= ~AH_PIN;
		BL_PORT &= ~BL_PIN;
		CH_PORT &= ~CH_PIN;
		CL_PORT &= ~CL_PIN;
		
		BH_PORT |= BH_PIN;
		AL_PORT |= AL_PIN;
		
		EICRA = ( 1 << ISC21 ) |( 1 << ISC20 );
		EIMSK = 1 << SENSORS_C_INT;																		// HABILITA INTERRUP��O PARA ZCP C
		SENSORS_PIN_CHG = 0X06;																			// PINOS DO SENSOR DEVEM ESTAR COM VALOR 100
		if(ZCP_DETECTED) 	calculateRPM();
		break;
		
		case HS_C|LS_A:																					// SECTOR 5
		AH_PORT &= ~AH_PIN;
		BL_PORT &= ~BL_PIN;
		BH_PORT &= ~BH_PIN;
		CL_PORT &= ~CL_PIN;
		
		CH_PORT |= CH_PIN;
		AL_PORT |= AL_PIN;
		
		EICRA = ( 1 << ISC11 );
		EIMSK = 1 << SENSORS_B_INT;																		// HABILITA INTERRUP��O PARA ZCP B
		SENSORS_PIN_CHG = 0X04;																			// PINOS DO SENSOR DEVEM ESTAR COM VALOR 100
		if(ZCP_DETECTED) 	calculateRPM();
		break;
		
		case HS_A|LS_C:																					// SECTOR 2
		AL_PORT &= ~AL_PIN;
		BL_PORT &= ~BL_PIN;
		BH_PORT &= ~BH_PIN;
		CH_PORT &= ~CH_PIN;
		
		AH_PORT |= AH_PIN;
		CL_PORT |= CL_PIN;
		
		EICRA = ( 1 << ISC11 ) |( 1 << ISC10 );
		EIMSK = 1 << SENSORS_B_INT;																		// HABILITA INTERRUP��O PARA ZCP B
		SENSORS_PIN_CHG = 0X03;																			// PINOS DO SENSOR DEVEM ESTAR COM VALOR 100
		if(ZCP_DETECTED) 	calculateRPM();
		break;
		
		case HS_A|LS_B:																					// SECTOR 1
		AL_PORT &= ~AL_PIN;
		BH_PORT &= ~BH_PIN;
		CL_PORT &= ~CL_PIN;
		CH_PORT &= ~CH_PIN;
		
		AH_PORT |= AH_PIN;
		BL_PORT |= BL_PIN;
		
		EICRA = ( 1 << ISC21 );
		EIMSK = 1 << SENSORS_C_INT;																		// HABILITA INTERRUP��O PARA ZCP C
		SENSORS_PIN_CHG = 0X01;																			// PINOS DO SENSOR DEVEM ESTAR COM VALOR 100
		if(ZCP_DETECTED) 	calculateRPM();
		break;
		
		case HS_B|LS_C:																					// SECTOR 3
		AL_PORT &= ~AL_PIN;
		AH_PORT &= ~AH_PIN;
		BL_PORT &= ~BL_PIN;
		CH_PORT &= ~CH_PIN;
		
		BH_PORT |= BH_PIN;
		CL_PORT |= CL_PIN;
		
		EICRA = ( 1 << ISC01 );
		EIMSK = 1 << SENSORS_A_INT;																		// HABILITA INTERRUP��O PARA ZCP A
		SENSORS_PIN_CHG = 0X02;																			// PINOS DO SENSOR DEVEM ESTAR COM VALOR 100
		if(ZCP_DETECTED) 	calculateRPM();
		break;
		
		default:
		break;
	}
}

ISR(INT0_vect){
	int i, zcp_ok = 1;
		
	for(i = 1; i < 40; i++) {
		SENSORS_PIN = (SENSORS_PORT & 0x07);
		if(SENSORS_PIN == SENSORS_PIN_CHG)
			zcp_ok ++;
	}
	
	if(zcp_ok < 20){
		return;
	}
		
	step_Sector = (step_Sector + 1) % 6;																// PROXIMO SETOR
	PreDriver_Sequence = Sector_DIR_Sequence[step_Sector];												// LE O NOVO SETOR NO VETOR
	Sector_Update(PreDriver_Sequence);
	
	if(!ZCP_DETECTED){
		ZCP_DETECTED = 1;
		ZCP_ON_PORT |= ZCP_ON_PIN;
	}	
}

ISR(INT1_vect){
	int i, zcp_ok = 1;
	
	for(i = 1; i < 40; i++) {
		SENSORS_PIN = (SENSORS_PORT & 0x07);
		if(SENSORS_PIN == SENSORS_PIN_CHG)
			zcp_ok ++;
	}
	
	if(zcp_ok < 20){
		return;
	}
		
	step_Sector = (step_Sector + 1) % 6;																// PROXIMO SETOR
	PreDriver_Sequence = Sector_DIR_Sequence[step_Sector];												// LE O NOVO SETOR NO VETOR
	Sector_Update(PreDriver_Sequence);																	// REALIZADA A TROCA DO SETOR
	
	if(!ZCP_DETECTED){
		ZCP_DETECTED = 1;
		ZCP_ON_PORT |= ZCP_ON_PIN;
	}
}

ISR(INT2_vect){
	int i, zcp_ok = 1;
	
	for(i = 1; i < 40; i++) {
		SENSORS_PIN = (SENSORS_PORT & 0x07);
		if(SENSORS_PIN == SENSORS_PIN_CHG)
			zcp_ok ++;
	}
	
	if(zcp_ok < 20){
		return;
	}
		
	step_Sector = (step_Sector + 1) % 6;																// PROXIMO SETOR
	PreDriver_Sequence = Sector_DIR_Sequence[step_Sector];												// LE O NOVO SETOR NO VETOR
	Sector_Update(PreDriver_Sequence);																	// REALIZADA A TROCA DO SETOR
	
	if(!ZCP_DETECTED){
		ZCP_DETECTED = 1;
		ZCP_ON_PORT |= ZCP_ON_PIN;
	}
}

void GPIO_INIT(void) {
	SENSORS_DDR &= ~(SENSORS_A_PIN | SENSORS_B_PIN | SENSORS_C_PIN);									// ENTRADA DE SINAL DE ZCP OU HALL (PORT B)
	ZCP_ON_DDR |= ZCP_ON_PIN;																			// SAIDA PARA INDICA��O DO MF
	
	AL_DDR |= AL_PIN;																					// PINOS DE GATE DOS MOSFET'S
	AH_DDR |= AH_PIN;
	BL_DDR |= BL_PIN;
	BH_DDR |= BH_PIN;
	CL_DDR |= CL_PIN;
	CH_DDR |= CH_PIN;
	
	HS_PWM_DDR |= HS_PWM_PIN;																			// PINO DE SAIDA DO PWM PARA AS CHAVES HIGH
}

void ADC_init(void) {
  ADMUX = 1 << REFS0;																					// AVCC with external capacitor at AREF pin
																										// MUX5:0 = 100000
  ADCSRB |= 1 << MUX5;
  ADCSRA |= 1 << ADEN | 1 << ADPS2;																		// ADC sampling rate = 16MHz/16 = 1 MHz
}

void Timer2_config(void) {
  
  TCCR2A |= 1 << WGM20 | 1 << WGM21;
  TCCR2B |= 1 << WGM22;																					// MODO FAST PWM COM OCR2A SENDO O TOPO
  OCR2A = TIMER2_PWM_PERIOD;
  Current_PWM_DutyCycle = MIN_PWM_DUTYCYCLE;															// VALOR INICIAL DE 5%
  OCR2B = Current_PWM_DutyCycle;
  TCCR2A |= 1 << COM2B1;																				// RESETA O CONTADOR AO CHEGAR EM OCR2B
}

void Timer3_config(void) {
	TCCR3A = 0;																							// MODO NORMAL
	TCCR3B = 0;																							// PRESCALER DE 0
	TIMSK3 |= (1 << TOIE3);																				// HABILITA A FLAG DE OVERFLOW (MEDIR VELOCIDADE)
}

void Timer5_config(void) {
	TCCR5A = 0;																							// MODO NORMAL
	TCCR5B = 0;																							// PRESCALER DE 0
	TIMSK5 |= (1 << TOIE5);																				// HABILITA A FLAG DE OVERFLOW (GERAR DELAY)
}

ISR(TIMER2_OVF_vect) {
  ADC_Sample_Counter++;																					// INCREMENTA O NUMERO DE AMOSTRAS
  
  if(ADC_Sample_Counter > ADC_SAMPLING_PWM_PERIODS)														// VERIFICA SE OCORRERAM MAIS DE 10 AMOSTRAGENS
		{
			ADC_Sample_Counter = 0x0;																	// LIMPA O CONTADOR
			SampleADC = true;																			// NUMERO DE AMOSTRAS ALCAN�ADA
		}
			
	if (Desired_PWM_DutyCycle > Current_PWM_DutyCycle)
		Current_PWM_DutyCycle = Current_PWM_DutyCycle + PWM_DutyCycle_Step;								// INCREMENTA
	else if (Desired_PWM_DutyCycle < Current_PWM_DutyCycle)
		Current_PWM_DutyCycle = Current_PWM_DutyCycle - PWM_DutyCycle_Step;								// DECREMENTA
    
	if (Current_PWM_DutyCycle >= TIMER2_PWM_PERIOD * 0.90 ) return;
	if (Current_PWM_DutyCycle <= TIMER2_PWM_PERIOD * 0.30 ) return;
	
  OCR2B = Current_PWM_DutyCycle;																		// APLICA NOVO DUTY CICLE NO PWM
}

ISR(TIMER3_OVF_vect) {
	overflowCountTimer3++;																				// INCREMENTA A CONTAGEM DE OVERFLOW
}

ISR(TIMER5_OVF_vect) {
	overflowCountTimer5++;																				// INCREMENTA A CONTAGEM DE OVERFLOW
}

void Get_ADC_Value(void) {
  ADCSRA |= 1 << ADSC;																					// INICIA A LEITURA DO POTENCIOMETRO
  while(ADCSRA & (1 << ADSC));																			// AGUARDA A LEITURA TERMINAR
  curADC = ADC;
  if ((curADC > (prevADC + 10)) || (curADC < (prevADC - 10)))											//  VERIFICA SE A MUDAN�A E' SIGNIFICATIVA
		{
			prevADC = curADC;
			Temp_DutyCycle = (prevADC/1023.0) * TIMER2_PWM_PERIOD;										// AJUSTA O DUTY CICLE DE ACORDO COM A % DO VALOR LIDO

			Desired_PWM_DutyCycle = Temp_DutyCycle;														// ARMAZENA O NOVO VALOR CONSIDERADO
		}
}

void calculateRPM(void) {
	
	currentTimerValue = TCNT3;																									// LE O VALOR DO TIMER 3
	if(overflowCountTimer3 == 0){
			totalTicksTimer3 = (uint32_t)(currentTimerValue - lastTimerValue);
	}
	if(overflowCountTimer3 > 0){
		overflowCountTimer3 = overflowCountTimer3 - 1;
		totalTicksTimer3 = ((uint32_t)overflowCountTimer3 * 65535) + (uint32_t)(currentTimerValue + (65535 - lastTimerValue));	// CALCULA O TOTAL DE TICKS DO TEMPORIZADOR	
	}
	
	intervalTimer3_Sec = totalTicksTimer3 * 62.5e-9;																			// 62.5ns POR TICK DO TEMPORIZADOR
	if (intervalTimer3_Sec > 0 && lastTimerValue != 0){
		
		motorRPM_PREV = ((Angle_Per_Sector/360.0)/(intervalTimer3_Sec/60.0))/5.0;										                    // FORMULA PARA CALCULA A VELOCIDADE MECANICA A CADA PULSO DO ZCP
		if( motorRPM_PREV < 5000){
			motorRPM = ( motorRPM + motorRPM_PREV)/2;
		}
	}
	
	overflowCountTimer3 = 0;
	lastTimerValue = currentTimerValue;																							// ARMAZENA O VALOR ATUAL PARA FUTURAS COMPARACOES
}

void delayTimer5_ms(int16_t tempDelay) {
	
	totalTicksTimer5 = 0;
	delayTicks = (int32_t)tempDelay*16000;
	TCNT5 = 0;																							// LIMPA O TIMER
	TCCR5B = (1 << CS50);																				// PRESCALER DE 1
	
	while((totalTicksTimer5 < delayTicks) && !ZCP_DETECTED){
		totalTicksTimer5 = ((uint32_t)overflowCountTimer5 * 65536) + TCNT5;
	}
	TCCR5B = 0;																							// PRESCALER IGUAL A 0 (PARA O CONTADOR)
	overflowCountTimer5 = 0;
}

void delayTimer5_us(int16_t tempDelay) {
	
	totalTicksTimer5 = 0;
	delayTicks = (int32_t)tempDelay*16;																	// Ajuste para microsegundos (16 MHz clock)
	TCNT5 = 0;																							// LIMPA O TIMER
	TCCR5B = (1 << CS50);																				// PRESCALER DE 1
	
	while((totalTicksTimer5 < delayTicks) && !ZCP_DETECTED){
		totalTicksTimer5 = ((uint32_t)overflowCountTimer5 * 65536) + TCNT5;
	}
	TCCR5B = 0;																							// PRESCALER IGUAL A 0 (PARA O CONTADOR)
	overflowCountTimer5 = 0;
}

void setPWMValue(double dutycycle_PWM){
	if ( dutycycle_PWM < 0.0 || dutycycle_PWM > 1.0) return;
	OCR2B = dutycycle_PWM * OCR2A;																		// DEFINE O DUTYCYCLE
}