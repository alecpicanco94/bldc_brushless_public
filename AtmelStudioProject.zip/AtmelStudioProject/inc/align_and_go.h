/*
 * align_and_go.h
 *
 * Created: 07/11/2024 05:38:50
 *  Author: alec_
 */ 

#ifndef ALIGN_AND_GO_H_
#define ALIGN_AND_GO_H_

// Constantes de configura��o do motor
#define ALIGN_TIME_MS 200                               // Tempo de alinhamento em milissegundos
#define INITIAL_FREQ_S 1                                // Frequ�ncia inicial em Hz
#define FINAL_FREQ_HZ 10                                // Frequ�ncia final para a partida
#define FREQUENCY_STEP 1                                // Incremento de frequ�ncia durante a acelera��o

// Fun��es de configura��o
void setupTimer3();
void startAlign();
void accelerate();

// Vari�veis globais
volatile uint16_t pulseFrequency = INITIAL_FREQ_S ;  // Frequ�ncia inicial
volatile unsigned int aligning = 1;                  // Flag de alinhamento

#endif /* ALIGN_AND_GO_H_ */
