/*
 * hall_sensor.h
 *
 * Created: 12/11/2024 10:07:47
 *  Author: alec_
 */ 

#ifndef HALL_SENSOR_
#define HALL_SENSOR_

/****************************************************************************
 *						MOTOR OUTPUT - GATE MOSFET'S SIGNALS                *
 ****************************************************************************/
#define LS_A 	0x01     	// Chave 1
#define HS_A 	0x02     	// Chave 2
#define LS_B 	0x04     	// Chave 3
#define HS_B 	0x08     	// Chave 4
#define LS_C 	0x10     	// Chave 5
#define HS_C 	0x20     	// Chave 6

#endif