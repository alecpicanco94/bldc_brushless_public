/*
 * main.h
 *
 * Created: 07/11/2024 11:42:41
 *  Author: Alec Pican�o de Azevedo Lopes
 */ 


#ifndef MAIN_H_
#define MAIN_H_

/* DEFINICAO DE PINOS SD PARA OS DRIVERS IR2110 */
#define IR_SD_DDR DDRJ
#define IR_SD_PORT PINJ
#define IRA_SD_PIN 0x01

/* DEFINICAO DE PINOS PARA INDICACAO DE MODO ZCP */
#define ZCP_ON_DDR DDRB
#define ZCP_ON_PORT PINB
#define ZCP_ON_PIN 0x01

/* DEFINICAO DE PINOS DE ENTRADA DO SENSOR DE ZCP */
#define SENSORS_DDR DDRD
#define SENSORS_PORT PIND
#define SENSORS_A_PIN 0x01
#define SENSORS_B_PIN 0x02
#define SENSORS_C_PIN 0x04
#define SENSORS_A_INT 0
#define SENSORS_B_INT 1
#define SENSORS_C_INT 2

#define AL_DDR DDRB
#define AL_PORT PORTB
#define AL_PIN 0x40

#define AH_DDR DDRB
#define AH_PORT PORTB
#define AH_PIN 0x20

#define BL_DDR DDRE
#define BL_PORT PORTE
#define BL_PIN 0x10

#define BH_DDR DDRE
#define BH_PORT PORTE
#define BH_PIN 0x08

#define CL_DDR DDRH
#define CL_PORT PORTH
#define CL_PIN 0x10

#define CH_DDR DDRH
#define CH_PORT PORTH
#define CH_PIN 0x08

#define HS_PWM_DDR DDRH 
#define HS_PWM_PIN 0x40

unsigned char Sector_DIR_Sequence[] = {
	HS_A|LS_B,																							// Sector 1 | PORTB = 000
	HS_A|LS_C,																							// Sector 2 | PORTB = 001
	HS_B|LS_C,																							// Sector 3 | PORTB = 010
	HS_B|LS_A,																							// Sector 4 | PORTB = 101
	HS_C|LS_A,																							// Sector 5 | PORTB = 110
	HS_C|LS_B,																							// Sector 6 | PORTB = 111
	0x00,
	0x00
};

// Motor and Commutation Variables
unsigned int	Desired_PWM_DutyCycle, 
				Current_PWM_DutyCycle, 
				PWM_BucketStep, 
				PWM_Update_Counter, 
				ADC_Sample_Counter, 
				Temp_DutyCycle;

unsigned char	PreDriver_Sequence,	
				SENSORS_PIN, 
				SENSORS_PIN_PREV = 0x00, 
				SENSORS_PIN_CHG, 
				SENSORS_PIN_LEVEL;


/****************************************************************************
 *	                 FUNCOES PARA LER OU DEFINIR VALORES                    *
 ****************************************************************************/
void Sector_Update (unsigned char Next_Hall_Sequence);
void Stop_Motor(void);
void Get_ADC_Value(void);
void setPWMValue(double dutycycle_PWM);
void newSector_Commutation(unsigned char SENSORS_PIN_TEMP, unsigned char SENSORS_PIN_CHG_TEMP);

/****************************************************************************
 *	    FUNCOES PARA CONFIGURAR OS PERIFERICOS DO MICROCONTROLADOR          *
 ****************************************************************************/
static void GPIO_INIT(void);
static void ADC_init(void);
static void Timer2_config(void);

#endif