/*
 * majoritariFunction.h
 *
 * Created: 05/11/2024 12:53:09
 *  Author: alec_
 */ 


#ifndef MAJORITARIFUNCTION_H_
#define MAJORITARIFUNCTION_H_





#endif /* MAJORITARIFUNCTION_H_ */