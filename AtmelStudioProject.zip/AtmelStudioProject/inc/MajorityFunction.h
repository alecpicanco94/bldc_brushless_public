
/* Output Logic sensors */
#define BEMF_SENSORS_MODER DDRL
#define BEMF_SENSORS_IDR PINL
#define BEMF_U_PIN 0x01
#define BEMF_V_PIN 0x02
#define BEMF_W_PIN 0x04

/* BEMF input sensor */
#define COMP_SENSORS_MODER DDRD
#define COMP_SENSORS_IDR PIND
#define COMP_U_PIN 0x01
#define COMP_V_PIN 0x02
#define COMP_W_PIN 0x04

//****************************************************************************//
// Defini��o dos vetores circulares
//****************************************************************************//

#define VETOR_SIZE 1000

volatile uint8_t vetor[VETOR_SIZE];
volatile uint8_t idx = 0;

//****************************************************************************//
// Timer para realizar as leituras do estado
//****************************************************************************//

void Timer1_config();
void Timer1_Start(void);
void Timer1_Stop(void);
void detectaPinoMajoritario();

void Timer1_config(void) {
	// Configura o timer para gerar interrup��es a cada 20 microsegundos (50kHz)
	TCCR1A = 0;
	TCCR1B = (1 << WGM12) | (1 << CS10);  // Modo CTC com prescaler 1
	OCR1A = 31;                           // Define o valor de compara��o para 2 �s (500kHz) a 16 MHz
	TIMSK1 = (1 << OCIE1A);               // Habilita interrup��o de compara��o A
}

void detectaPinoMajoritario(void) {
	uint16_t contagem_u = 0, contagem_v = 0, contagem_w = 0;
	uint16_t contagem_zeros_u = 0, contagem_zeros_v = 0, contagem_zeros_w = 0;

	// Itera pelo vetor circular e conta as ocorr�ncias de 1 e 0 em cada pino
	for (uint8_t i = 0; i < idx ; i++) {
		if (vetor[i] & HALL_U_PIN) {
			contagem_u++;
			} else {
			contagem_zeros_u++;
		}
		
		if (vetor[i] & HALL_V_PIN) {
			contagem_v++;
			} else {
			contagem_zeros_v++;
		}
		
		if (vetor[i] & HALL_W_PIN) {
			contagem_w++;
			} else {
			contagem_zeros_w++;
		}
	}

	// Avalia cada fase e define os pinos de sa�da em PINL
	if (contagem_u > contagem_zeros_u) {
		BEMF_SENSORS_IDR |= COMP_U_PIN;  // Ativa o pino U
		} else {
		BEMF_SENSORS_IDR &= ~COMP_U_PIN; // Desativa o pino U
	}

	if (contagem_v > contagem_zeros_v) {
		BEMF_SENSORS_IDR |= COMP_V_PIN;  // Ativa o pino V
		} else {
		BEMF_SENSORS_IDR &= ~COMP_V_PIN; // Desativa o pino V
	}

	if (contagem_w > contagem_zeros_w) {
		BEMF_SENSORS_IDR |= COMP_W_PIN;  // Ativa o pino W
		} else {
		BEMF_SENSORS_IDR &= ~COMP_W_PIN; // Desativa o pino W
	}
}

ISR(TIMER1_COMPA_vect) {
	
	// Captura os estados dos pinos de Hall
	uint8_t hall_state = COMP_SENSORS_IDR & (COMP_U_PIN | COMP_V_PIN | COMP_W_PIN);
	
	// Armazena no vetor circular
	vetor[idx] = hall_state;
	idx = idx + 1;
	idx = (idx + 1) % VETOR_SIZE;      // Atualiza o indice circular
}

void Timer1_Start(void) {
	TCCR1B |= (1 << CS10);             // Ativa o Timer1 com prescaler 1
}

void Timer1_Stop(void) {
	TCCR1B &= ~(1 << CS10);            // Desativa o Timer1
	TCNT1 = 0;                         // Zera o Timer 1 para come�ar a contagem
}