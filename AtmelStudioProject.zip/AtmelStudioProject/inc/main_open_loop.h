/*
 * main_open_loop.h
 *
 * Created: 12/11/2024 10:28:44
 *  Author: alec_
 */ 

#ifndef OPEN_LOOP_
#define OPEN_LOOP_

/***************************************************************************
 *                       DEFINICOES GERAIS DO SISTEMA	     		       *
 ***************************************************************************/
#define SYSTEM_FREQ 16000000UL																			// (Hz) FREQUENCIA DE CLOCK DO MEGA2560
#define F_CPU SYSTEM_FREQ																				// (HZ) NECESSARIO PARA USAR A FUNCAO DELAY NO ATMELSTUDIO
#define PWM_FREQ 30000																					// (Hz) FREQUENCIA DE CHAVEAMENTO DOS MOSFETS
#define TIMER2_PRESCALER 32																				// PRESCALER DO TEMPORIZADOR 2
#define TIMER2_PWM_PERIOD ((SYSTEM_FREQ)/PWM_FREQ/TIMER2_PRESCALER)										// PERIODO DO TEMPORIZADOR 2 PARA GERAR PWM_FREQ (FAST PWM)
#define DUTYCYCLE_MIN 5																					// (%) DUTYCICLE MINIMO
#define MIN_PWM_DUTYCYCLE ((TIMER2_PWM_PERIOD)*(DUTYCYCLE_MIN))/100
#define TIMER3_PRESCALER 1																				// PRESCALER DO TEMPORIZADOR 3
#define TIMER5_PRESCALER 8																				// PRESCALER DO TEMPORIZADOR 5

//****************************************************************************//
// Motor Status Definitions
//****************************************************************************//
#define Stopped 0x00																					// VARIAVEL PARA INDICAR MOTOR PARADO
#define StartUp 0x01																					// VARIAVEL PARA INDICAR MOTOR EM PARTIDA
#define Running 0x02																					// VARIAVEL PARA INDICAR MOTOR EM MF
#define true 0x01																						// DEFINICAO DE VARIAL TRUE
#define false 0x0																						// DEFINICAO DE VARIAL FALSE

volatile uint16_t	currentTimerValue,
					lastTimerValue,
					overflowCountTimer3 = 0,
					overflowCountTimer5 = 0;

volatile uint32_t	totalTicksTimer3,
					totalTicksTimer5,
					delayTicks;

volatile double		intervalTimer3_Sec,
					motorRPM,
					motorRPM_PREV;

volatile int		Step_Min = 0, 
					delay = 0;

void Timer5_config(void);
void delayTimer5_ms(int16_t tempDelay);
void delayTimer5_us(int16_t tempDelay);
void Align_Motor(int16_t delayms_align, double dutycycle_align);
void Start_Motor(void);

#endif