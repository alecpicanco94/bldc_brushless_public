/*
 * IncFile1.h
 *
 * Created: 06/11/2024 17:39:04
 *  Author: alec_
 */ 

// Defini��es dos par�metros do motor
#define J 0.01         // Momento de in�rcia do motor
#define B 0.001        // Constante de atrito

volatile float velocidade_angular = 0.0;  // Velocidade angular atual do motor
volatile float torque_aplicado = 0.0;     // Torque aplicado no motor
volatile uint8_t motor_ativado = 0;       // Status do motor (0 = desligado, 1 = ligado)

void Timer3_init();
void Timer3_stop();
void update_sequence(void);

void start_motor_open_loop(float torque) {
	// Inicia o motor em malha aberta, aplicando um torque inicial
	torque_aplicado = torque;
	motor_ativado = 1;
	Timer3_init();  // Configura o Timer3 para controle da acelera��o
	while(1){motor_ativado = 1;}
}

void stop_motor_open_loop() {
	motor_ativado = 0;  // Desativa o motor
	Timer3_stop();      // Para o Timer3
	velocidade_angular = 0.0;
}

// Inicializa o Timer3 para gerar interrup��es de controle de acelera��o
void Timer3_init() {
	TCCR3A = 0;                            // Configura Timer3 no modo normal
	TCCR3B = (1 << WGM32) | (1 << CS31);   // Modo CTC com prescaler de 8
	OCR3A = 19999;                         // Valor de compara��o para 10ms a 16MHz com prescaler 8
	TIMSK3 = (1 << OCIE3A);                // Habilita interrup��o de compara��o do Timer3
}

// Fun��o para parar o Timer3
void Timer3_stop() {
	TCCR3B &= ~((1 << CS31) | (1 << CS30));  // Para o Timer3
	TCNT3 = 0;                               // Zera o contador do Timer3
}

// Interrup��o de controle de acelera��o (Timer3)
ISR(TIMER3_COMPA_vect) {
	if (motor_ativado) {
		// Calcula a acelera��o com base no torque, atrito e velocidade atual
		float aceleracao_angular = (torque_aplicado - B * velocidade_angular) / J;

		// Atualiza a velocidade angular com a acelera��o calculada
		velocidade_angular += aceleracao_angular * 0.01;  // ?t = 10ms (0.01s)

		// Define o pr�ximo valor de Duty Cycle baseado na velocidade atual
		uint16_t duty_cycle = (uint16_t)(velocidade_angular * 10);  // Exemplo de convers�o

		// Limita o duty cycle ao m�ximo suportado
		if (duty_cycle > TIMER_PWM_PERIOD) {
			duty_cycle = TIMER_PWM_PERIOD;
		}
		
		OCR2B = duty_cycle;  // Aplica o novo duty cycle no registrador OCR2B
	}
}

void update_sequence(void) {
	// Atualiza a sequ�ncia de fases do motor com base no valor do hall_index
	uint8_t next_phase = Hall_DIR_sequence[hall_index];
	PWM_update(next_phase);            // Atualiza a fase do motor
	
	// Atualiza o �ndice da sequ�ncia para a pr�xima fase
	hall_index = (hall_index + 1) % 6; // A sequ�ncia deve seguir o ciclo de 6 fases
}
