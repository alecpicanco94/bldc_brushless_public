/*
 * main_close_loop.h
 *
 * Created: 12/11/2024 10:29:35
 *  Author: alec_
 */ 

#ifndef CLOSE_LOOP_
#define CLOSE_LOOP_

/***************************************************************************
 *                  MOTOR SPEED CONTROL - ADC VARIABLES				       *
 ***************************************************************************/
volatile int			curADC,																			// VALOR CORRENTE ADC
						prevADC = 0,																	// VALOR ANTERIOR ADC
						ZCP_DETECTED = 0,																// DETECCAO DE ZCP
						step_Sector;																	// SETOR ACIONADO

volatile unsigned char	SampleADC = false;																// DETECTOR DE AMOSTRA ADC

/***************************************************************************
 *                  MOTOR SPEED CONTROL - OPEN LOOP DEFINITIONS		       *
 ***************************************************************************/
#define ADC_SAMPLING_PWM_PERIODS 10																		// NUMERO DE AMOSTRAS DO ADC
#define PWM_DutyCycle_Step 1																			// VARIACAO DO PWM ATE ALCANCAR A VELOCIDADE DESEJADA
#define N_Pair_Pole 5																					// NUMERO DE PARES DE POLOS
#define Angle_Per_Sector 60.0																			// ANGULO MECANICO DE DETECCAO DE ZCP
#define Total_Elec_Distance 360.0*N_Pair_Pole															// COMPRIMENTO TOTAL DE UM PULSO

void Timer3_config(void);																				// CONFIGURA TIMER PARA CALCULO DE VELOCIDADE
void calculateRPM(void);																				// FUNCAO PARA CALCULAR VELOCIDADE ATRAV�S DO ZCP
#endif